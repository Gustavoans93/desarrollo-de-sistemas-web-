﻿<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Resultados de datos</title>
    <link rel="stylesheet" href="./Styles/Style.css">
</head>
<body>
    <?php 
        // Obtener los valores del formulario
        $Name = isset($_POST['Name']) ? $_POST['Name'] : "No ingresado";
        $age = isset($_POST['age']) ? $_POST['age'] : "No ingresado";
        $City = isset($_POST['City']) ? $_POST['City'] : "No ingresado";
        $hobby = isset($_POST['hobby']) ? $_POST['hobby'] : "No ingresado";
        $birthday = isset($_POST['birthday']) ? $_POST['birthday'] : "No ingresado";
    ?>

    <div class="dive2">
        <center>
            <h1>Resultados</h1>
            <img src="images.png" alt="Imagen de resultados">
        </center>
        <h2>¡Bien Hecho!</h2>

        <p><strong>Nombre:</strong> <?php echo htmlspecialchars($Name); ?></p>
        <p><strong>Edad:</strong> <?php echo htmlspecialchars($age); ?></p>
        <p><strong>Ciudad:</strong> <?php echo htmlspecialchars($City); ?></p>
        <p><strong>Hobby:</strong> <?php echo htmlspecialchars($hobby); ?></p>
        <p><strong>Fecha de nacimiento:</strong> <?php echo htmlspecialchars($birthday); ?></p>

        <div id="popUpOverlay"></div>
        <div id="popUpBox">
            <div id="Box">
                <i class="fas fa-question-circle fa-5x"></i>
                <h1>¿Volver a ingresar los datos?</h1>
                <div id="closeModal">
                    <button onclick="window.location.href='index.php'">¡Sí, quiero!</button>
                </div>
            </div>
        </div>

        <button onclick="Alert.render()">Volver a ingresar</button>

        <script src="./script/Script1.js"></script>
    </div>
</body>
</html>
