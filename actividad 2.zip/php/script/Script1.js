var Alert = new customAlert();

function customAlert() {
    this.render = function () {
        let popUpBox = document.getElementById('popUpBox');
        popUpBox.style.display = "block";

        document.getElementById('closeModal').innerHTML = '<button onclick="window.location.href=\'index.php\'">¡Sí, quiero!</button>';
    };

    this.ok = function () {
        document.getElementById('popUpBox').style.display = "none";
        document.getElementById('popUpOverlay').style.display = "none";
    };
}
