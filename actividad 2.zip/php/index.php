<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Formulario de Datos</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="dive">
    <h1>Captura Datos personales</h1>
 <br>
 <h2>Ingresa Los Datos Que Se Te Piden</h2>
 <br>
 <p>Mi primera encuesta</p>
 <hr />
        <h1>Formulario de Registro</h1>
        <form action="Resultados.php" method="POST">
            <label for="Name">Nombre:</label>
            <input type="text" id="Name" name="Name" required><br><br>

            <label for="age">Edad:</label>
            <input type="number" id="age" name="age" required><br><br>

            <label for="City">Ciudad:</label>
            <input type="text" id="City" name="City" required><br><br>

            <label for="hobby">Hobby:</label>
            <input type="text" id="hobby" name="hobby" required><br><br>

            <label for="birthday">Fecha de Nacimiento:</label>
            <input type="date" id="birthday" name="birthday" required><br><br>
            <a href="Resultados.php">
            <input type="submit" value="Enviar">
        </form>
    </div>
</body>
</html>
